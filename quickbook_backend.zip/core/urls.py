from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    UserViewSet, ClientProfileViewSet, ServiceProviderProfileViewSet,
    ServiceViewSet, BookingViewSet, EmployeeViewSet, FinancialReportViewSet
)

router = DefaultRouter()
router.register(r'users', UserViewSet)
router.register(r'clients', ClientProfileViewSet)
router.register(r'providers', ServiceProviderProfileViewSet)
router.register(r'services', ServiceViewSet)
router.register(r'bookings', BookingViewSet)
router.register(r'employees', EmployeeViewSet)
router.register(r'reports', FinancialReportViewSet)

urlpatterns = [
    path('', include(router.urls)),
]