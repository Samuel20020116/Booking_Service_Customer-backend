from django.contrib import admin
from .models import User, ClientProfile, ServiceProviderProfile, Service, Booking, Employee, FinancialReport

admin.site.register(User)
admin.site.register(ClientProfile)
admin.site.register(ServiceProviderProfile)
admin.site.register(Service)
admin.site.register(Booking)
admin.site.register(Employee)
admin.site.register(FinancialReport)