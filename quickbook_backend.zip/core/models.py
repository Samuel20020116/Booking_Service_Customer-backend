from django.contrib.auth.models import AbstractUser
from django.db import models

# User roles
USER_ROLE_CHOICES = (
    ('client', 'Client'),
    ('provider', 'Service Provider'),
    ('admin', 'Admin'),
)

class User(AbstractUser):
    role = models.CharField(max_length=20, choices=USER_ROLE_CHOICES, default='client')
    email = models.EmailField(unique=True)
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.email

class ClientProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='client_profile')
    phone = models.CharField(max_length=20, blank=True)

class ServiceProviderProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='provider_profile')
    business_name = models.CharField(max_length=255)
    address = models.TextField(blank=True)
    phone = models.CharField(max_length=20, blank=True)

class Service(models.Model):
    provider = models.ForeignKey(ServiceProviderProfile, on_delete=models.CASCADE, related_name='services')
    title = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    duration_minutes = models.IntegerField()

    def __str__(self):
        return f"{self.title} - {self.provider.business_name}"

class Booking(models.Model):
    client = models.ForeignKey(ClientProfile, on_delete=models.CASCADE, related_name='bookings')
    service = models.ForeignKey(Service, on_delete=models.CASCADE, related_name='bookings')
    booking_time = models.DateTimeField()
    status = models.CharField(max_length=50, choices=(
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ), default='pending')

class Employee(models.Model):
    provider = models.ForeignKey(ServiceProviderProfile, on_delete=models.CASCADE, related_name='employees')
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=100)

class FinancialReport(models.Model):
    provider = models.ForeignKey(ServiceProviderProfile, on_delete=models.CASCADE, related_name='financial_reports')
    date_generated = models.DateField(auto_now_add=True)
    total_earnings = models.DecimalField(max_digits=12, decimal_places=2)
    notes = models.TextField(blank=True)